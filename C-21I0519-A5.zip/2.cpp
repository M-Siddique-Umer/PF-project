//*************************************
//Name: Muhammad Siddique Umer                              
//Roll- no: 21i0519
// section: 213-c
// it is program which takes loan as input then it takes installment as input the by using loop it iterates till
// the paid amount becomes equal to the loan amount and then it shows a table in which the penalities and 
// all other details of the payment is given
//**************************************

#include<iostream>//using input output stream
using namespace std;

void bank(){//making function to solve problem


    int M=0,N=0,O=0;
char s;//a character 
while(s!='N' and  s!='n'){//condition to iterate loop again and again
int amount,install;//declaring integers
string Date1,Date2;//declaring two strings
int due[install],paid[install];//delcaring integer arrays used in the program
string a[50] , b[50];//declaring string arrays
int x,y,sum=0;//sum for the difference of days
int fine[install]={0};
int table[2][2];//using 2d array
    int balance[install]={0};
    int days[50]={0};//Arrays to store panality,days,balance.
cout << "Enter the total  ammount of the loan " << endl;
cin >> amount;//taking input total amount of loan
    
cout << "Enter the number of isntallments: "<< endl;
cin >> install;//taking total installments of the loan

for(int i=0;i<install;i++){
cout << "Enter Due Amount: "<< endl;
cin >> due[i];//taking due date from the user

cout << "Enter Due Date: " << endl;
cin >> Date1;
a[i] = Date1;

cout << "Enter the Paid Ammount: " << endl;
cin >> paid[i];//taking paid amount from the user

cout << "Enter Paid Date: " << endl;
cin>>Date2;//taking paid amount from the user

b[i] = Date2;
// here we are calculating the generall total days starting from 1st day to till date 
x = (Date1[0] * 10) + (Date1[1]) + (Date1[3]*30*10) + (Date1[4]*30) + (Date1[6]*1000*365) + (Date1[7]*100*365) + (Date1[8] * 10 *365) + (Date1[9] * 365);
y = (Date2[0] * 10) + (Date2[1]) + (Date2[3]*30*10) + (Date2[4]*30) + (Date2[6]*1000*365) + (Date2[7]*100*365) + (Date2[8] * 10 *365) + (Date2[9] * 365);
sum = (x - y);//taking difference of paid date and due date

if (sum>0){
sum=0;//if sum is positive the 0 is store in number of days
days[i]=0;
}
if(sum<0){//if paid date is greater than due date then penality of 100 per day will be calculated
days[i] = (sum * -1);
sum = ((sum * -1) *100);
}

         
if(paid[i]<due[i]){// if paid amount is less than due amount then penality of 5% will be calcualted 
   sum  = sum + (due[i] * 0.05);
}
fine[i] = sum ;

if((due[i]-paid[i])>0){//calculating balance due amount minues paid amount
   balance[i] = due[i] - paid[i];
}
sum=0;

M = M+due[i];//taking sum for summary 
 N = N + paid[i];//taking sum for summary table
 O = O + fine[i];//taking sum for summary table
}   
      //displaying the table  
        cout << "S: NO" << "      "<< "Due Amount"<<"     "<<"Due Date"<< "       "<<"Paid Amount"<<"     "<<"Paid Date"<< "      "<<"Penalty"<<"     "<< "Number of days" << "   "<< "balance" <<endl;
for(int k=0;k<install;k++){
   cout << k+1 << "            ";
   cout <<due[k] << "           ";
   cout <<a[k] << "           ";//Due date
   cout <<paid[k] << "           ";
  cout <<b[k] << "           ";//Paid date
   cout <<fine[k]<<"        ";
cout <<days[k] << "         ";
cout <<balance[k] << "          ";
cout<<endl;
}

cout << "Summary: " << endl;
cout << "total  "<<"Due amount " << M << "    " << "Paid Amount " << N << "  " << "fine " << O << endl;
cout << "Charges: " << O << endl;
cout << "Do you want to continue: yes or no " << endl;
cin >> s;
}
return ;
}
int main(){

bank();//calling the function into main

return 0;
}
